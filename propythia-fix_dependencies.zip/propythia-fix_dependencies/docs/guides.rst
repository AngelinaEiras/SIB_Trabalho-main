
Guides
==================

.. important:: View the guides for propythia
.. only:: builder_html

    - View `pdf to user guide <../_static/propythia_user_guide.pdf>`_.
    - View `pdf to descriptors guide <../_static/descriptors_guide.pdf>`_.
    :download: `pdf to descriptors guide <../_guides/descriptors_guide.pdf>`_.


For an in-depth explanation, please see :download:`A Detailed Example <../_guides/descriptors_guide.pdf>`.
