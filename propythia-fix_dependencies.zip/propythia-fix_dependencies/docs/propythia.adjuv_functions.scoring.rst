Adjuv functions: Scoring
==========================================

scores
------------------------------------------------

.. automodule:: propythia.adjuv_functions.scoring.scores
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: propythia.adjuv_functions.scoring
   :members:
   :undoc-members:
   :show-inheritance:
