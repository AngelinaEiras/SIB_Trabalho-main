Adjuv functions: Sequence
===========================================

get_sequence
--------------------------------------------------------

.. automodule:: propythia.adjuv_functions.sequence.get_sequence
   :members:
   :undoc-members:
   :show-inheritance:

get_sized_seq
----------------------------------------------------------

.. automodule:: propythia.adjuv_functions.sequence.get_sized_seq
   :members:
   :undoc-members:
   :show-inheritance:

get_sub_seq
--------------------------------------------------------

.. automodule:: propythia.adjuv_functions.sequence.get_sub_seq
   :members:
   :undoc-members:
   :show-inheritance:

pro_check
-----------------------------------------------------

.. automodule:: propythia.adjuv_functions.sequence.pro_check
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: propythia.adjuv_functions.sequence
   :members:
   :undoc-members:
   :show-inheritance:
