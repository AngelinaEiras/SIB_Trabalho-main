#!/usr/bin/env bash

sphinx-apidoc -o
make html